// Homework 3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "List342.h"
#include "Bird.h"
#include "Child.h"

using namespace std;

void BirdTest();
void ChildTest();

int _tmain(int argc, _TCHAR* argv[])
{
	
	BirdTest();
	//ChildTest();

	return 0;
}

void BirdTest()
{
	List342<Bird> list("test.txt");

	cout << list << endl;

	//Bird peekTest("bird is the word", 0);

	//list->Remove(*b3, peekTest);
	//list->Peek(*b1,peekTest);

	//cout << *list << endl;

	//// Test Clear List
	//list->ClearList();

	//cout << *list << endl;

	//// Insert birds again
	//list->Insert(NULL);
	//list->Insert(b2);
	//list->Insert(b4);
	//list->Insert(b3);
	//list->Insert(b1);

	//cout << *list << endl;

	// Copy Constructor Test
	//List342<Bird> list2 = *list;

	//cout <<"LIST1" << endl << list2 << endl;

	//list->ClearList();

	//cout << "List 1 DELETED" << endl;

	//cout << "LIST1" << endl << *list << endl;
	//cout << list->getCount() << endl;

	//cout << "LIST2" << endl << list2 << endl;
	//cout << list2.getCount() << endl;

	//cout << (*list == list2) << endl;

	List342<Bird> list2("test.txt");
	List342<Bird> list3;

	//list3 += list2;
	//list2.ClearList();
	list3.Insert(new Bird("chocobo", 777));
	list3.Insert(new Bird("null", 0));
	list3.Merge(list, list2);
	//list3.Insert(new Bird("tell", 0));

	cout << list3 << endl;
	cout << list3.getCount() << endl;
}


void ChildTest()
{
	List342<Child> clist("testc.txt");

	cout << clist << endl;
}

